Scoped job: add farewell().
